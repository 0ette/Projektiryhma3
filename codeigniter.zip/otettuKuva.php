<html>
<body bgcolor=CCCCCC>
    <tr>
        <td width="400px"></td>
        <td width="100px"><a href="http://stulinux53.ipt.oamk.fi/codeigniter/">Home</a></td>
    </tr>
<?php
$host='localhost';
$dbname='codeigniter';
$username='ryhma3';
$password='meolemmeryhma3';

$con=mysqli_connect($host,$username,$password,$dbname);
if (mysqli_connect_errno()) {
echo "Fail !";
}
$result2 = $con->query("SELECT * FROM photoTaken order by created DESC");
 While($imgData = $result2->fetch_assoc()){  

    echo '<div align="left">';
    echo "<br>";
    echo '<img width="40%" height="40%" src="http://stulinux53.ipt.oamk.fi/codeigniter/application/models/'.$imgData['name'].'"/>';
    echo "<br>". $imgData['created'] . "</div>" ;
}
mysqli_close($con);
?>
</body>
</html>