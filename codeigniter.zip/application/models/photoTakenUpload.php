<?php
 
date_default_timezone_set('Europe/Helsinki');                      
$dateTime = date("Y-m-d H:i:s");
 
$host='localhost';
$dbname='codeigniter';
$username='ryhma3';
$password='meolemmeryhma3';

$con=mysqli_connect($host,$username,$password,$dbname);
if (mysqli_connect_errno()) {
echo "Fail !";
}
     
$image = $_FILES["file"]["name"];
$insert = $con->query("INSERT into photoTaken (name, created) VALUES ('$image', '$dateTime')");
if($insert){
    move_uploaded_file($_FILES["file"]["tmp_name"],$_FILES["file"]["name"]);
}
 
?>
