<html>
<table height="230px" background="hiiri.jpg">
    <tr>
        <td colspan="3"></td>
        <td colspan="3" style="font-size: 4em; color: 00005e; font-weight: bold" valign="bottom">Hiirenloukku</td>
    </tr>
    <tr>
        <td colspan="3"></td>
        <td colspan="4" style="font-size: 2em; color: a3a3c2; font-weight: bold;" valign="top">Ryhmä 3 </td>
    </tr>
    <tr>
        <td width="400px"></td>
        <td width="100px"><a href="http://stulinux53.ipt.oamk.fi/codeigniter/">Home</a></td>
        <td width="100px"><a href="otaKuva.html">Ota kuva</a><td>
        <td width="100px"><a href="hiiriTauluLoki.php">Hiiri-taulun loki</a></td>
        <td width="100px"><a href="kuvaLoki.php">Kuvien loki</a></td>
    </tr>
</table>


<?php
$host='localhost';
$dbname='codeigniter';
$username='ryhma3';
$password='meolemmeryhma3';

$con=mysqli_connect($host,$username,$password,$dbname);
if (mysqli_connect_errno()) {
echo "Fail !";
}
$result = mysqli_query($con,"SELECT * FROM hiiri order by idkaappaus DESC limit 1"); 
echo '<div align="center">';
echo "<table border='1'> 
<tr> 
<th>Hiiri</th> 
<th>Tayttoaste</th> 
</tr>"; 
while($row = mysqli_fetch_array($result)) { 
    echo "<br>";
    echo "<tr>"; 
    echo "<td>" . $row['idkaappaus'] . "</td>"; 
    echo "<td>" . $row['tayttoaste'] . "</td>"; 
    echo "</tr>". "</div>";

} 
echo "</table>";

$result2 = $con->query("SELECT * FROM rpiimage order by created DESC limit 1");
 While($imgData = $result2->fetch_assoc()){  

    echo '<div align="center">';
    echo "<br>";
    echo '<img width="40%" height="40%" src="http://stulinux53.ipt.oamk.fi/codeigniter/application/models/'.$imgData['name'].'"/>';
    echo "<br>". $imgData['created'] . "</div>" ;
}

mysqli_close($con);
?>

	
</html>
