<!DOCTYPE html>
<html lang="en">
<head>
<title>Hiirenloukku</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
}

/* Style the header */
header {
  background-color: #666;
  padding: 5px;
  text-align: center;
  font-size: 35px;
  color: white;
}

/* Create two columns/boxes that floats next to each other */
nav {
  float: left;
  width: 30%;
  height: 420px; /* only for demonstration, should be removed */
  background: #ccc;
  padding: 20px;
}

/* Style the list inside the menu */
nav ul {
  list-style-type: none;
  padding: 0;
}

article {
  float: left;
  padding: 20px;
  width: 70%;
  background-color: #f1f1f1;
  height: 420px; /* only for demonstration, should be removed */
}

/* Clear floats after the columns */
section:after {
  content: "";
  display: table;
  clear: both;
}

/* Style the footer */
footer {
  background-color: #777;
  padding: 20px;
  text-align: center;
  color: white;
}

/* Responsive layout - makes the two columns/boxes stack on top of each other instead of next to each other, on small screens */
@media (max-width: 600px) {
  nav, article {
    width: 100%;
    height: auto;
  }
}
</style>
</head>
<body>

<h2>Hiirenloukku</h2>
<p>Ryhmä 3</p>
<p>Robin Huumonen, Juho Kantola, Atte Paananen</p>

<header>
  <h2>Hiiret :D</h2>
</header>

<section>
  <nav>
    <ul>
      <li><a href="otaKuva.html">Ota kuva</a></li>
      <li><a href="hiiriTauluLoki.php">Hiiritaulun loki</a></li>
      <li><a href="kuvaLoki.php">Kuvien loki</a></li>
    </ul>
  </nav>
  
  <article>
    <h1>Viimeisin hiiri:</h1>
    <?php
$host='localhost';
$dbname='codeigniter';
$username='ryhma3';
$password='meolemmeryhma3';

$con=mysqli_connect($host,$username,$password,$dbname);
if (mysqli_connect_errno()) {
echo "Fail !";
}
$result = mysqli_query($con,"SELECT * FROM hiiri order by idkaappaus DESC limit 1"); 
echo '<div align="left">';
echo "<table border='1'> 
<th>Hiiri</th> 
<th>Tayttöaste</th> 
</tr>"; 
while($row = mysqli_fetch_array($result)) { 
    echo "<br>";
    echo "<tr>"; 
    echo "<td>" . $row['idkaappaus'] . "</td>"; 
    echo "<td>" . $row['tayttoaste'] . "</td>"; 
    echo "</tr>". "</div>";

} 
echo "</table>";

$result2 = $con->query("SELECT * FROM rpiimage order by created DESC limit 1");
 While($imgData = $result2->fetch_assoc()){  

    echo '<div align="center">';
    echo '<img width="35%" height="35%" src="http://stulinux53.ipt.oamk.fi/codeigniter/application/models/'.$imgData['name'].'"/>';
    echo "<br>". $imgData['created'] . "</div>" ;
}
mysqli_close($con);
?>
  </article>
</section>

<footer>
  <p>2019 Oulun ammattikorkeakoulu</p>
</footer>

</body>
</html>