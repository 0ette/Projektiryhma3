<html>
<body bgcolor=#ccc>

<?php
$host='localhost';
$dbname='codeigniter';
$username='ryhma3';
$password='meolemmeryhma3';

$con=mysqli_connect($host,$username,$password,$dbname);
if (mysqli_connect_errno()) {
echo "Fail !";
}
$result = mysqli_query($con,"SELECT * FROM hiiri");
echo '<div align="left">'; 
echo "<table border='1'> 
<tr> 
<th>Hiiri</th> 
<th>Tayttoaste</th> 
</tr>"; 
while($row = mysqli_fetch_array($result)) { 
    echo "<tr>"; 
    echo "<td>" . $row['idkaappaus'] . "</td>"; 
    echo "<td>" . $row['tayttoaste'] . "</td>"; 
    echo "</tr>". "</div>";

} 
echo "</table>";
mysqli_close($con);
?>
</body>
</html>